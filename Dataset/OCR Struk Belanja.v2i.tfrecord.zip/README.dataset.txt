# OCR Struk Belanja > 2024-11-23 2:03am
https://universe.roboflow.com/ocr-struk-belanja-gpcd0/ocr-struk-belanja-mx7qi

Provided by a Roboflow user
License: CC BY 4.0

